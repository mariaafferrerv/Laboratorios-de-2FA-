<?php
session_start();
include("clases/mysql.inc.php");
$db = new mod_db();

include("clases/SanitizarEntrada.php");
include("comunes/loginfunciones.php");
include("clases/objLoginAdmin.php");

use Sonata\GoogleAuthenticator\GoogleAuthenticator;

$tokenizado = false;

// =====================================================
// Validación CSRF
// =====================================================
$token_enviado = $_POST['tolog'] ?? '';
$token_almacenado = $_SESSION['csrf_token'] ?? '';

if ($token_enviado !== '' && $token_almacenado !== '' && hash_equals($token_almacenado, $token_enviado)) {
    $tokenizado = true;
} else {
    $tokenizado = false;
    $sess = session_id();
    $stored = substr($token_almacenado, 0, 8);
    $sent = substr($token_enviado, 0, 8);
    $Usuario = $_POST['usuario'] ?? '';
    error_log("[CSRF] mismatch. session_id={$sess} stored_prefix={$stored} sent_prefix={$sent} user={$Usuario}");
}

// =====================================================
// 🔑 Validar Login
// =====================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $tokenizado) {

    $Usuario = trim($_POST['usuario']);
    $ClaveKey = trim($_POST['contrasena']);
    $ipRemoto = $_SERVER['REMOTE_ADDR'];

    $Logearme = new ValidacionLogin($Usuario, $ClaveKey, $ipRemoto, $db);

    if ($Logearme->logger()) {
        $Logearme->autenticar();

        if ($Logearme->getIntentoLogin()) {
            // ✅ LOGIN CORRECTO
            $_SESSION['autenticado'] = "SI";
            $_SESSION['Usuario'] = $Logearme->getUsuario();

            $_SESSION['autenticado'] = "SI"; // <-- 🔥 Esto faltaba


            // Asegurar formato consistente (correo o usuario)
            if (strpos($_SESSION['Usuario'], '@') === false) {
                $buscarCorreo = $db->getConexion()->prepare("SELECT Correo FROM usuarios WHERE Usuario = :user");
                $buscarCorreo->bindParam(":user", $_SESSION['Usuario']);
                $buscarCorreo->execute();
                $dato = $buscarCorreo->fetch(PDO::FETCH_ASSOC);
                if ($dato && !empty($dato['Correo'])) {
                    $_SESSION['Usuario'] = $dato['Correo'];
                }
            }

            // Registrar intento
            if (!$Logearme->registrarIntentos()) {
                error_log("Fallo al registrar intento de login para usuario: " . $Usuario);
            }

            // Guardar sesión antes de redirigir
            session_write_close();

            // =====================================
            // 🚀 INTEGRACIÓN DE 2FA
            // =====================================
            try {
                $conn = $db->getConexion();
                $stmt = $conn->prepare("SELECT id, secret_2fa FROM usuarios WHERE Usuario = :user OR Correo = :user");
                $stmt->bindParam(":user", $_SESSION['Usuario']);
                $stmt->execute();
                $usuarioData = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($usuarioData) {
                    $_SESSION['usuario_id'] = $usuarioData['id'];
                    $_SESSION['secret_2fa'] = $usuarioData['secret_2fa'] ?? null;

                    session_write_close();

                    // Si ya tiene 2FA activado, va a verificación
                    if (!empty($usuarioData['secret_2fa'])) {
                        redireccionar("verificar_login_2fa.php");
                        exit;
                    } else {
                        // Si no tiene 2FA, va a activar el QR
                        redireccionar("activar_2fa.php");
                        exit;
                    }
                } else {
                    // Si no se encuentra el usuario, entra normal al panel
                    redireccionar("formularios/PanelControl.php");
                    exit;
                }

            } catch (Exception $e) {
                error_log("Error verificando 2FA: " . $e->getMessage());
                redireccionar("formularios/PanelControl.php");
                exit;
            }

        } else {
            // ❌ Contraseña incorrecta
            if (!$Logearme->registrarIntentos()) {
                error_log("Fallo al registrar intento de login para usuario: " . $Usuario);
            }

            $_SESSION["emsg"] = 1;
            session_write_close();
            redireccionar("login.php");
        }

    } else {
        // ❌ Usuario no encontrado
        if (!$Logearme->registrarIntentos()) {
            error_log("Fallo al registrar intento de login para usuario: " . $Usuario);
        }

        $_SESSION["emsg"] = 1;
        session_write_close();
        redireccionar("login.php");
    }

} else {
    // ❌ CSRF o método no permitido
    $tokenizado = false;
    $_SESSION["emsg"] = 1;
    session_write_close();
    redireccionar("login.php");
}
?>
