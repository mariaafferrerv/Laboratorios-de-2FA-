		
			
			<link rel="stylesheet" href="../css/custom.css">
<div class="row">
                    <div class="row-item col-1_3">
					<!-- Icon Box -->
					<div class="b-service">
						<div class="service-image m-programming">
						</div>
						<h3 class="centered">Etiqueta</h3>
						<p class="centered">
                        <a href="#" class="dark-link">Etiqueta 1</a>
						</p>
					</div>
					<!-- End Icon Box -->
				</div>
				<div class="row-item col-1_3">
					<!-- Icon Box -->
					<div class="b-service">
						<div  class="service-image m-literature">
						</div>
						<h3 class="centered">Etiqueta 2</h3>
						<p class="centered"><a href="#" class="dark-link"> M&oacute;dulo 2</a></p></a>
                        
					</div>
					<!-- End Icon Box -->
				</div>
				<div class="row-item col-1_3">
					<!-- Icon Box -->
					<div class="b-service">
						<div class="service-image m-creative-writing">
						</div>
						<h3 class="centered">Etiqueta 3</h3>
						<p class="centered"><a href="#" class="dark-link">M&oacute;dulo 3</a></p></a>
						
					</div>
					<!-- End Icon Box -->
				</div>
			
			</div>
		

<div class="row">

	<div class="row-item col-1_4">
					<!-- Icon Box -->
					<div class="b-service">
						<div class="service-image m-drawing">
						</div>
						<h3 class="centered"><a href="#" class="dark-link">Etiqueta 4</a></h3>
						<p class="centered">
							M&oacute;dulo 4
						</p>
					</div>
					<!-- End Icon Box -->
				</div>
				<div class="row-item col-1_4">
					<!-- Icon Box -->
					<div class="b-service">
						<div class="service-image m-game-development">
						</div>
						<h3 class="centered"><a href="#" class="dark-link">Etiqueta 5</a></h3>
						<p class="centered">
							 M&oacute;dulo 5
						</p>
					</div>
					<!-- End Icon Box -->
				</div>
				<div class="row-item col-1_4">
					<!-- Icon Box -->
					<div class="b-service">
						<div class="service-image m-painting">
						</div>
						<h3 class="centered"><a href="#" class="dark-link">Etiqueta 6</a></h3>
						<p class="centered">
							M&oacute;dulo 6
						</p>
					</div>
					<!-- End Icon Box -->
				</div>		
</div>
