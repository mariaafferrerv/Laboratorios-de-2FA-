<?php
//Ejemplo n.° 4 Ejemplo de password_hash() con Argon2i
echo 'Argon2i hash: ' . password_hash('rasmuslerdorf', PASSWORD_ARGON2I);
?>