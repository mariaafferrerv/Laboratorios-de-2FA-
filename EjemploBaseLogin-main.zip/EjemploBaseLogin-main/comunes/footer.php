<div id="footer">
	
			<span id="footer-left">
				&copy; Universidad Tecnol&oacute;gica de Panam&aacute; |
				Design by for <strong>Ing. Irina Fong. </strong></span>
						
			
				<span id="footer-right">
<a href="#">UTP</a> <?php  echo date('Y');?>| UTP- Ingenier&iacute;a WEB</span><!-- wrap ends here -->		
</div>