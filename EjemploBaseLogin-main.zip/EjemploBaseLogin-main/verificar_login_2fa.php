<?php
// ==============================================
// Verificación del código 2FA en el login
// Adaptado para clase mod_db y base company_info
// ==============================================

require 'vendor/autoload.php';
require_once("clases/mysql.inc.php");

use Sonata\GoogleAuthenticator\GoogleAuthenticator;

session_start();

// Verificar si existe la sesión del usuario
if (!isset($_SESSION["usuario_id"]) || !isset($_SESSION["usuario_nombre"])) {
    die("❌ No se detectó sesión activa. Inicia sesión nuevamente.");
}

// Conexión a la base de datos
$db = new mod_db();
$conn = $db->getConexion();

// Obtener el secreto guardado del usuario
$id_usuario = $_SESSION["usuario_id"];
$stmt = $conn->prepare("SELECT secret_2fa FROM usuarios WHERE id = :id");
$stmt->bindParam(":id", $id_usuario);
$stmt->execute();
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario || empty($usuario["secret_2fa"])) {
    // Si el usuario no tiene 2FA configurado, se salta directamente
    header("Location: index.php");
    exit;
}

$secret = $usuario["secret_2fa"];
$mensaje = "";

// Procesar el formulario cuando el usuario envíe el código
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $codigo = $_POST["codigo"] ?? '';
    $g = new GoogleAuthenticator();

    if ($g->checkCode($secret, $codigo)) {
        // ✅ Código correcto: acceso permitido
        $_SESSION["verificado_2fa"] = true;
        header("Location: index.php");
        exit;
    } else {
        $mensaje = "❌ Código incorrecto. Inténtalo nuevamente.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Verificación 2FA</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f6fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            text-align: center;
        }
        input {
            padding: 10px;
            width: 200px;
            margin-bottom: 10px;
        }
        button {
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
        }
        button:hover {
            background-color: #0056b3;
        }
        .mensaje {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<form method="POST">
    <h2>Verificación de Segundo Factor (2FA)</h2>
    <?php if ($mensaje): ?>
        <div class="mensaje"><?= $mensaje ?></div>
    <?php endif; ?>
    <input type="text" name="codigo" placeholder="Código de 6 dígitos" required><br>
    <button type="submit">Verificar</button>
</form>

</body>
</html>
